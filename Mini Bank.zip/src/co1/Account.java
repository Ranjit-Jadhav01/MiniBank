package co1;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private String accountNumber;
    private double balance;
    private String accountHolderName;
    private List<String> transactionHistory;

    public Account(String accountNumber, double balance, String accountHolderName) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.accountHolderName = accountHolderName;
        this.transactionHistory = new ArrayList<>();
        transactionHistory.add("Account created with balance: " + balance);
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
        transactionHistory.add("Deposited: " + amount);
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            transactionHistory.add("Withdrew: " + amount);
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public List<String> getTransactionHistory() {
        return transactionHistory;
    }

    public void credit(double amount) {
        deposit(amount);
        transactionHistory.add("Credited: " + amount);
    }

    public void debit(double amount) {
        withdraw(amount);
        transactionHistory.add("Debited: " + amount);
    }
}