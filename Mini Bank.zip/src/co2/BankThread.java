package co2;

import co1.Account;

public class BankThread extends Thread {
    private Account account;
    private double amount;

    public BankThread(Account account, double amount) {
        this.account = account;
        this.amount = amount;
    }

    @Override
    public void run() {
        synchronized (account) {
            account.deposit(amount);
            System.out.println("Deposited " + amount + " to account " + account.getAccountNumber());
        }
    }
}