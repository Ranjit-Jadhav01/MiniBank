package co3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import co1.Account;
import co1.SavingsAccount;

public class BankAppGUI extends JFrame {
    private JTextField accountNumberField;
    private JTextField balanceField;
    private JTextField accountHolderNameField;
    private JButton createAccountButton;
    private JButton checkBalanceButton;
    private JButton getAccountHolderNameButton;
    private JButton checkTransactionHistoryButton;
    private JButton deleteAccountButton;
    private JButton creditButton;
    private JButton debitButton;

    private Account account;

    public BankAppGUI() {
        setTitle("Theva Ani Visara Bank");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel bankNameLabel = new JLabel("Theva Ani Visara Bank", JLabel.CENTER);
        bankNameLabel.setFont(new Font("Serif", Font.BOLD, 24));
        add(bankNameLabel, BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel accountNumberLabel = new JLabel("Account Number:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(accountNumberLabel, gbc);

        accountNumberField = new JTextField(15);
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(accountNumberField, gbc);

        JLabel balanceLabel = new JLabel("Initial Balance:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(balanceLabel, gbc);

        balanceField = new JTextField(15);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(balanceField, gbc);

        JLabel accountHolderNameLabel = new JLabel("Account Holder Name:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(accountHolderNameLabel, gbc);

        accountHolderNameField = new JTextField(15);
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(accountHolderNameField, gbc);

        createAccountButton = new JButton("Create Account");
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(createAccountButton, gbc);

        checkBalanceButton = new JButton("Check Balance");
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(checkBalanceButton, gbc);

        getAccountHolderNameButton = new JButton("Get Account Holder Name");
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(getAccountHolderNameButton, gbc);

        checkTransactionHistoryButton = new JButton("Check Transaction History");
        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(checkTransactionHistoryButton, gbc);

        deleteAccountButton = new JButton("Delete Account");
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(deleteAccountButton, gbc);

        creditButton = new JButton("Credit Amount");
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(creditButton, gbc);

        debitButton = new JButton("Debit Amount");
        gbc.gridx = 1;
        gbc.gridy = 6;
        panel.add(debitButton, gbc);

        add(panel, BorderLayout.CENTER);

        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String accountNumber = accountNumberField.getText();
                double balance = Double.parseDouble(balanceField.getText());
                String accountHolderName = accountHolderNameField.getText();
                account = new SavingsAccount(accountNumber, balance, accountHolderName, 2.0); // example interest rate
                JOptionPane.showMessageDialog(null, "Account Created: " + accountNumber);
            }
        });

        checkBalanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (account != null) {
                    double balance = account.getBalance();
                    JOptionPane.showMessageDialog(null, "Account Balance: " + balance);
                } else {
                    JOptionPane.showMessageDialog(null, "No account exists.");
                }
            }
        });

        getAccountHolderNameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (account != null) {
                    String accountHolderName = account.getAccountHolderName();
                    JOptionPane.showMessageDialog(null, "Account Holder Name: " + accountHolderName);
                } else {
                    JOptionPane.showMessageDialog(null, "No account exists.");
                }
            }
        });

        checkTransactionHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (account != null) {
                    List<String> transactionHistory = account.getTransactionHistory();
                    JOptionPane.showMessageDialog(null, "Transaction History: " + transactionHistory.toString());
                } else {
                    JOptionPane.showMessageDialog(null, "No account exists.");
                }
            }
        });

        deleteAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (account != null) {
                    account = null;
                    JOptionPane.showMessageDialog(null, "Account Deleted.");
                } else {
                    JOptionPane.showMessageDialog(null, "No account exists.");
                }
            }
        });

        creditButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (account != null) {
                    new CreditAmountDialog().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "No account exists.");
                }
            }
        });

        debitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (account != null) {
                    new DebitAmountDialog().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "No account exists.");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BankAppGUI().setVisible(true);
            }
        });
    }

    // Dialog for crediting amount
    class CreditAmountDialog extends JDialog {
        private JTextField amountField;

        public CreditAmountDialog() {
            setTitle("Credit Amount");
            setSize(300, 150);
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel amountLabel = new JLabel("Amount:");
            gbc.gridx = 0;
            gbc.gridy = 0;
            add(amountLabel, gbc);

            amountField = new JTextField(15);
            gbc.gridx = 1;
            gbc.gridy = 0;
            add(amountField, gbc);

            JButton creditButton = new JButton("Credit");
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 2;
            add(creditButton, gbc);

            creditButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    double amount = Double.parseDouble(amountField.getText());
                    account.credit(amount);
                    JOptionPane.showMessageDialog(null, "Amount Credited: " + amount);
                    dispose();
                }
            });
        }
    }

    // Dialog for debiting amount
    class DebitAmountDialog extends JDialog {
        private JTextField amountField;

        public DebitAmountDialog() {
            setTitle("Debit Amount");
            setSize(300, 150);
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel amountLabel = new JLabel("Amount:");
            gbc.gridx = 0;
            gbc.gridy = 0;
            add(amountLabel, gbc);

            amountField = new JTextField(15);
            gbc.gridx = 1;
            gbc.gridy = 0;
            add(amountField, gbc);

            JButton debitButton = new JButton("Debit");
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 2;
            add(debitButton, gbc);

            debitButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    double amount = Double.parseDouble(amountField.getText());
                    account.debit(amount);
                    JOptionPane.showMessageDialog(null, "Amount Debited: " + amount);
                    dispose();
                }
            });
        }
    }
}