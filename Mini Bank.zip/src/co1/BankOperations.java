package co1;

import java.util.List;

public interface BankOperations {
    void openAccount();
    void closeAccount();
    void transferFunds(Account fromAccount, Account toAccount, double amount);
    double checkBalance(Account account);
    String getAccountHolderName(Account account);
    List<String> getTransactionHistory(Account account);
    void deleteAccount(Account account);
}